import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:wc2026/features/matches/presentation/widgets/date_filter.dart';
import 'package:wc2026/features/matches/presentation/widgets/group_filter.dart';
import 'package:wc2026/features/matches/presentation/widgets/match_card.dart';
import 'package:wc2026/features/matches/presentation/widgets/match_list.dart';
import 'package:wc2026/features/matches/presentation/widgets/stage_filter.dart';
import 'package:wc2026/features/profile/presentation/screens/profile_screen.dart';
import 'package:wc2026/features/rooms/presentation/screens/rooms_screen.dart';
import 'package:wc2026/features/standings/presentation/screens/standings_screen.dart';
import 'package:wc2026/shared/widgets/app_tab_bar.dart';
import 'package:wc2026/shared/widgets/app_search_bar.dart';
import 'package:wc2026/shared/widgets/empty_state.dart';
import 'package:wc2026/shared/widgets/loading_widget.dart';
import 'package:wc2026/shared/providers/repository_providers.dart';
import 'package:wc2026/core/constants/app_colors.dart';
import 'package:wc2026/features/matches/domain/entities/match_entity.dart';
import 'package:wc2026/features/home/presentation/widgets/bottom_nav.dart';
import 'package:wc2026/l10n/app_localizations.dart';
import 'package:wc2026/shared/providers/score_notifier.dart';

final currentIndexProvider = StateProvider<int>((ref) => 0);

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  @override
  void initState() {
    super.initState();
    // Démarre le service live au lancement de l'app
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(scoreNotifierProvider.notifier).initializeOnLaunch();
    });
  }

  @override
  void dispose() {
    ref.read(scoreNotifierProvider.notifier).stopTimer();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final currentIndex = ref.watch(currentIndexProvider);
    final scoreState = ref.watch(scoreNotifierProvider);

    final pages = [
      const _HomePage(),
      const _MatchesPage(),
      const _RoomsPage(),
      const StandingsScreen(),
      const _ProfilePage(),
    ];

    return Scaffold(
      body: Stack(
        children: [
          pages[currentIndex],
          // Badge live pulsant
          if (scoreState.liveMatchCount > 0 || scoreState.isRefreshingLive)
            Positioned(
              top: MediaQuery.of(context).padding.top + 8,
              right: 12,
              child: _LiveBadge(
                  liveCount: scoreState.liveMatchCount,
                  isRefreshing: scoreState.isRefreshingLive),
            ),
        ],
      ),
      bottomNavigationBar: BottomNav(
        currentIndex: currentIndex,
        onTap: (index) => ref.read(currentIndexProvider.notifier).state = index,
      ),
    );
  }
}

// Badge live pulsant
class _LiveBadge extends StatefulWidget {
  final int liveCount;
  final bool isRefreshing;
  const _LiveBadge({required this.liveCount, required this.isRefreshing});

  @override
  State<_LiveBadge> createState() => _LiveBadgeState();
}

class _LiveBadgeState extends State<_LiveBadge>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _anim = Tween<double>(begin: 0.5, end: 1.0)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.isRefreshing) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: AppColors.primary.withOpacity(0.9),
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
                width: 10,
                height: 10,
                child: CircularProgressIndicator(
                    color: Colors.white, strokeWidth: 1.5)),
            SizedBox(width: 4),
            Text('Sync...',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.w500)),
          ],
        ),
      );
    }
    return FadeTransition(
      opacity: _anim,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: AppColors.live.withOpacity(0.9),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(
          '🔴 LIVE · ${widget.liveCount}',
          style: const TextStyle(
              color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700),
        ),
      ),
    );
  }
}

class _HomePage extends ConsumerWidget {
  const _HomePage();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final todayAsync = ref.watch(todayMatchesProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.appName),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
      ),
      body: todayAsync.when(
        loading: () => const LoadingWidget(),
        error: (e, _) => EmptyState(
          emoji: '❌',
          message: l10n.connectionError,
          action: ElevatedButton(
            onPressed: () => ref.refresh(todayMatchesProvider),
            child: Text(l10n.retry),
          ),
        ),
        data: (matches) => matches.isEmpty
            ? EmptyState(
                emoji: '⚽',
                message: l10n.noMatchToday,
                subtitle: l10n.tournamentStarts,
              )
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: matches.length,
                itemBuilder: (context, index) =>
                    MatchCard(match: matches[index]),
              ),
      ),
    );
  }
}

class _MatchesPage extends ConsumerStatefulWidget {
  const _MatchesPage();

  @override
  ConsumerState<_MatchesPage> createState() => _MatchesPageState();
}

class _MatchesPageState extends ConsumerState<_MatchesPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _selectedGroup = 'Tous';
  String _selectedStage = 'Tous';
  String _searchQuery = '';
  DateTime? _selectedDate;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  List<MatchEntity> _applyFilters(List<MatchEntity> matches) {
    return matches.where((m) {
      if (_searchQuery.isNotEmpty) {
        final q = _searchQuery.toLowerCase();
        if (!m.homeTeamName.toLowerCase().contains(q) &&
            !m.awayTeamName.toLowerCase().contains(q)) {
          return false;
        }
      }
      switch (_tabController.index) {
        case 0:
          if (_selectedGroup != 'Tous') {
            final matchGroup = m.group
                    ?.replaceAll('GROUP_', '')
                    .replaceAll('Group ', '')
                    .trim() ??
                '';
            if (matchGroup != _selectedGroup) return false;
          }
          return m.stage == 'GROUP_STAGE';
        case 1:
          if (_selectedStage != 'Tous') return m.stage == _selectedStage;
          return m.stage != 'GROUP_STAGE';
        case 2:
          if (_selectedDate != null) {
            final local = m.utcDate.toLocal();
            return local.day == _selectedDate!.day &&
                local.month == _selectedDate!.month &&
                local.year == _selectedDate!.year;
          }
          return true;
      }
      return true;
    }).toList()
      ..sort((a, b) => a.utcDate.compareTo(b.utcDate));
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final matchesAsync = ref.watch(matchesProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text('${l10n.matches} WC 2026'),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        bottom: AppTabBar(
          controller: _tabController,
          onTap: () => setState(() {}),
          tabs: [
            AppTab(label: l10n.allGroups),
            AppTab(label: l10n.knockoutStage),
            AppTab(label: l10n.byDate),
          ],
        ),
      ),
      body: matchesAsync.when(
        loading: () => const LoadingWidget(),
        error: (e, _) => EmptyState(
          emoji: '❌',
          message: l10n.connectionError,
          action: ElevatedButton(
            onPressed: () => ref.refresh(matchesProvider),
            child: Text(l10n.retry),
          ),
        ),
        data: (matches) {
          final filtered = _applyFilters(matches);
          return Column(
            children: [
              AppSearchBar(
                controller: _searchController,
                hint: l10n.searchTeam,
                onChanged: (v) => setState(() => _searchQuery = v),
              ),
              if (_tabController.index == 0)
                GroupFilter(
                  selected: _selectedGroup,
                  onSelected: (v) => setState(() => _selectedGroup = v),
                )
              else if (_tabController.index == 1)
                StageFilter(
                  selected: _selectedStage,
                  onSelected: (v) => setState(() => _selectedStage = v),
                )
              else
                DateFilter(
                  selected: _selectedDate,
                  onSelected: (v) => setState(() => _selectedDate = v),
                ),
              Expanded(
                child: filtered.isEmpty
                    ? EmptyState(message: l10n.noMatchFound)
                    : MatchList(matches: filtered),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _RoomsPage extends StatelessWidget {
  const _RoomsPage();

  @override
  Widget build(BuildContext context) => const RoomsScreen();
}

class _ProfilePage extends StatelessWidget {
  const _ProfilePage();

  @override
  Widget build(BuildContext context) => const ProfileScreen();
}
