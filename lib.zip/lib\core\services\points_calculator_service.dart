import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:wc2026/features/pronostics/presentation/providers/pronostic_provider.dart';
import 'package:wc2026/features/rooms/data/repositories/room_repository_impl.dart';

/// Calcule et sauvegarde les points pour un user donné
/// Retourne true si des points ont été calculés
Future<bool> calculatePointsForUser({
  required String userId,
  required WidgetRef ref,
}) async {
  final db = FirebaseFirestore.instance;

  // Récupère tous les pronostics non calculés de cet user
  final pronosticsSnap = await db
      .collection('users')
      .doc(userId)
      .collection('pronostics')
      .where('isCalculated', isEqualTo: false)
      .get();

  if (pronosticsSnap.docs.isEmpty) return false;

  bool anyUpdated = false;

  for (final pronosticDoc in pronosticsSnap.docs) {
    final matchId = pronosticDoc.id;
    final pronosticData = pronosticDoc.data();

    // Lit le match depuis Firestore directement (score frais)
    final matchDoc = await db.collection('matches').doc(matchId).get();
    if (!matchDoc.exists) continue;

    final matchData = matchDoc.data()!;
    final status = matchData['status'] as String? ?? '';

    // Ne calcule que pour les matchs FINISHED
    if (status != 'FINISHED') continue;

    final homeScore = matchData['homeScore'] as int?;
    final awayScore = matchData['awayScore'] as int?;
    if (homeScore == null || awayScore == null) continue;

    // Calcul des points
    final points = _computePoints(pronosticData, homeScore, awayScore);

    // Sauvegarde en Firestore
    final batch = db.batch();
    batch.update(pronosticDoc.reference, {
      'points': points,
      'isCalculated': true,
    });

    // Stats user
    final Map<String, dynamic> statsUpdate = {
      'totalPoints': FieldValue.increment(points),
    };

    final totalGoals = homeScore + awayScore;
    final realWinner = homeScore > awayScore
        ? 1
        : awayScore > homeScore
            ? 2
            : 0;
    final type = pronosticData['type'] == 'exact' ? 'exact' : 'other';

    if (type == 'exact' && points == 25) {
      statsUpdate['exactScoreCount'] = FieldValue.increment(1);
    }
    if (type == 'other') {
      final winner = pronosticData['winner'] as int? ?? -1;
      final maxGoals = pronosticData['maxGoals'] as int? ?? -1;
      final minGoals = pronosticData['minGoals'] as int? ?? -1;
      if (winner != -1 && winner == realWinner) {
        statsUpdate['winnerCorrectCount'] = FieldValue.increment(1);
      }
      if (maxGoals != -1 && totalGoals <= maxGoals) {
        statsUpdate['maxGoalsCorrectCount'] = FieldValue.increment(1);
      }
      if (minGoals != -1 && totalGoals >= minGoals) {
        statsUpdate['minGoalsCorrectCount'] = FieldValue.increment(1);
      }
    }

    // Meilleur match
    final userDoc = await db.collection('users').doc(userId).get();
    final currentBest =
        (userDoc.data()?['bestMatchPoints'] as num?)?.toInt() ?? 0;
    if (points > currentBest) {
      statsUpdate['bestMatchId'] = matchId;
      statsUpdate['bestMatchPoints'] = points;
    }

    batch.update(db.collection('users').doc(userId), statsUpdate);
    await batch.commit();
    anyUpdated = true;
  }

  if (anyUpdated) {
    // Relit le totalPoints après les commits et met à jour les rooms
    final updatedUserDoc = await db.collection('users').doc(userId).get();
    final newTotal =
        (updatedUserDoc.data()?['totalPoints'] as num?)?.toInt() ?? 0;
    await RoomRepositoryImpl().updateMemberPoints(userId, newTotal);

    // Invalide le cache du profil via le trigger
    ref.read(profileRefreshTrigger.notifier).state++;
  }

  return anyUpdated;
}

/// Calcule les points live (provisoires) pour un user depuis les matchs en cours
/// Retourne Map<matchId, points> — jamais sauvegardé en Firestore
Future<Map<String, int>> calculateLivePointsForUser(String userId) async {
  final db = FirebaseFirestore.instance;
  final Map<String, int> result = {};

  // Tous les matchs IN_PLAY
  final liveMatchesSnap = await db
      .collection('matches')
      .where('status', whereIn: ['IN_PLAY', 'PAUSED']).get();

  if (liveMatchesSnap.docs.isEmpty) return result;

  for (final matchDoc in liveMatchesSnap.docs) {
    final matchData = matchDoc.data();
    final matchId = matchData['id'] as String? ?? matchDoc.id;
    final homeScore = matchData['homeScore'] as int?;
    final awayScore = matchData['awayScore'] as int?;
    if (homeScore == null) continue;

    // Lit le pronostic de cet user pour ce match
    final pronosticDoc = await db
        .collection('users')
        .doc(userId)
        .collection('pronostics')
        .doc(matchId)
        .get();

    if (!pronosticDoc.exists) continue;

    final pts = _computePoints(pronosticDoc.data()!, homeScore, awayScore ?? 0);
    result[matchId] = pts;
  }

  return result;
}

// ── Calcul interne ────────────────────────────────────────────────────────────

int _computePoints(Map<String, dynamic> data, int homeScore, int awayScore) {
  final type = data['type'] == 'exact' ? 'exact' : 'other';
  final totalGoals = homeScore + awayScore;
  final realWinner = homeScore > awayScore
      ? 1
      : awayScore > homeScore
          ? 2
          : 0;
  int pts = 0;

  if (type == 'exact') {
    final pHome = (data['homeScore'] as num?)?.toInt() ?? 0;
    final pAway = (data['awayScore'] as num?)?.toInt() ?? 0;
    if (pHome == homeScore && pAway == awayScore) pts = 25;
  } else {
    final winner = (data['winner'] as num?)?.toInt() ?? -1;
    final maxGoals = (data['maxGoals'] as num?)?.toInt() ?? -1;
    final minGoals = (data['minGoals'] as num?)?.toInt() ?? -1;
    if (winner != -1 && winner == realWinner) pts += 5;
    if (maxGoals != -1 && totalGoals <= maxGoals) {
      pts += ((7 - maxGoals) * 2).clamp(0, 14);
    }
    if (minGoals != -1 && totalGoals >= minGoals) {
      pts += (minGoals * 2).clamp(0, 14);
    }
  }
  return pts;
}
