import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:wc2026/features/matches/domain/entities/match_entity.dart';
import 'package:wc2026/features/pronostics/domain/entities/pronostic_entity.dart';
import 'package:wc2026/features/pronostics/domain/entities/user_stats_entity.dart';
import 'package:wc2026/features/pronostics/presentation/providers/pronostic_provider.dart';
import 'package:wc2026/features/rooms/data/repositories/room_repository_impl.dart';
import 'package:wc2026/shared/providers/repository_providers.dart';

// ─────────────────────────────────────────────────────────────────────────────
// STATE GLOBAL DE L'APPLICATION
// Source unique de vérité pour :
//   - Stats de l'utilisateur connecté
//   - Pronostics avec points calculés (définitifs + live)
//   - Points live par match (pour toutes les pages)
// ─────────────────────────────────────────────────────────────────────────────

class AppState {
  final UserStatsEntity? userStats;
  final List<PronosticEntity> pronostics;
  // matchId → points live calculés localement (jamais Firestore)
  final Map<String, int> livePointsByMatch;
  final bool isLoading;

  const AppState({
    this.userStats,
    this.pronostics = const [],
    this.livePointsByMatch = const {},
    this.isLoading = false,
  });

  AppState copyWith({
    UserStatsEntity? userStats,
    List<PronosticEntity>? pronostics,
    Map<String, int>? livePointsByMatch,
    bool? isLoading,
  }) {
    return AppState(
      userStats: userStats ?? this.userStats,
      pronostics: pronostics ?? this.pronostics,
      livePointsByMatch: livePointsByMatch ?? this.livePointsByMatch,
      isLoading: isLoading ?? this.isLoading,
    );
  }

  /// Points live pour un match donné (calcul local, non sauvegardé)
  int livePoints(String matchId) => livePointsByMatch[matchId] ?? 0;

  /// Pronostic pour un match donné
  PronosticEntity? pronosticFor(String matchId) {
    try {
      return pronostics.firstWhere((p) => p.matchId == matchId);
    } catch (_) {
      return null;
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// NOTIFIER
// ─────────────────────────────────────────────────────────────────────────────

final appStateProvider =
    StateNotifierProvider<AppStateNotifier, AppState>((ref) {
  return AppStateNotifier(ref);
});

class AppStateNotifier extends StateNotifier<AppState> {
  final Ref _ref;

  AppStateNotifier(this._ref) : super(const AppState());

  // ── Chargement initial au lancement de l'app ──────────────────────────────

  Future<void> initialize() async {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) return;

    state = state.copyWith(isLoading: true);

    // Charge stats et pronostics en parallèle
    final repo = _ref.read(pronosticRepositoryProvider);
    final results = await Future.wait([
      repo.getUserStats(userId),
      repo.getUserPronostics(userId),
    ]);

    final stats = results[0] as UserStatsEntity?;
    final pronostics = results[1] as List<PronosticEntity>;

    state = state.copyWith(
      userStats: stats,
      pronostics: pronostics,
      isLoading: false,
    );

    // Calcule les points pour les matchs terminés non encore calculés
    await _calculateFinishedMatches(pronostics);
  }

  // ── Recalcule les points live depuis les matchs en cours ──────────────────

  void updateLivePoints(List<MatchEntity> liveMatches) {
    final pronostics = state.pronostics;
    if (pronostics.isEmpty || liveMatches.isEmpty) return;

    final Map<String, int> newLivePoints = {};

    for (final match in liveMatches) {
      if (!match.isLive || match.homeScore == null) continue;

      final pronostic = state.pronosticFor(match.id);
      if (pronostic == null) continue;

      final pts =
          pronostic.calculatePoints(match.homeScore!, match.awayScore ?? 0);
      newLivePoints[match.id] = pts;
    }

    state = state.copyWith(livePointsByMatch: newLivePoints);
  }

  // ── Recharge les stats après sauvegarde d'un pronostic ───────────────────

  Future<void> refresh() async {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) return;

    final repo = _ref.read(pronosticRepositoryProvider);
    final results = await Future.wait([
      repo.getUserStats(userId),
      repo.getUserPronostics(userId),
    ]);

    state = state.copyWith(
      userStats: results[0] as UserStatsEntity?,
      pronostics: results[1] as List<PronosticEntity>,
    );
  }

  // ── Calcul et sauvegarde Firestore pour les matchs terminés ──────────────
  // Appelé une seule fois au lancement pour les matchs non encore calculés

  Future<void> _calculateFinishedMatches(
      List<PronosticEntity> pronostics) async {
    final uncalculated = pronostics.where((p) => !p.isCalculated).toList();
    if (uncalculated.isEmpty) return;

    final db = FirebaseFirestore.instance;
    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) return;

    bool anyCalculated = false;

    for (final pronostic in uncalculated) {
      // Lit le match depuis Firestore
      final matchDoc = await db
          .collection('matches')
          .where('id', isEqualTo: pronostic.matchId)
          .limit(1)
          .get();

      if (matchDoc.docs.isEmpty) continue;
      final matchData = matchDoc.docs.first.data();
      final status = matchData['status'] as String? ?? '';

      // Seulement pour les matchs terminés
      if (status != 'FINISHED') continue;

      final homeScore = matchData['homeScore'] as int?;
      final awayScore = matchData['awayScore'] as int?;
      if (homeScore == null || awayScore == null) continue;

      final points = pronostic.calculatePoints(homeScore, awayScore);

      // Sauvegarde en Firestore
      final batch = db.batch();

      // Met à jour le pronostic
      batch.update(
        db
            .collection('users')
            .doc(userId)
            .collection('pronostics')
            .doc(pronostic.matchId),
        {'points': points, 'isCalculated': true},
      );

      // Met à jour les stats user
      final Map<String, dynamic> statsUpdate = {
        'totalPoints': FieldValue.increment(points),
      };

      final totalGoals = homeScore + awayScore;
      final realWinner = homeScore > awayScore
          ? 1
          : awayScore > homeScore
              ? 2
              : 0;

      if (pronostic.isExactMode && points == 25) {
        statsUpdate['exactScoreCount'] = FieldValue.increment(1);
      } else {
        if (pronostic.winner != null &&
            pronostic.winner != -1 &&
            pronostic.winner == realWinner) {
          statsUpdate['winnerCorrectCount'] = FieldValue.increment(1);
        }
        if (pronostic.maxGoals != null &&
            pronostic.maxGoals != -1 &&
            totalGoals <= pronostic.maxGoals!) {
          statsUpdate['maxGoalsCorrectCount'] = FieldValue.increment(1);
        }
        if (pronostic.minGoals != null &&
            pronostic.minGoals != -1 &&
            totalGoals >= pronostic.minGoals!) {
          statsUpdate['minGoalsCorrectCount'] = FieldValue.increment(1);
        }
      }

      batch.update(db.collection('users').doc(userId), statsUpdate);
      await batch.commit();
      anyCalculated = true;
    }

    if (anyCalculated) {
      // Recharge les stats et met à jour les rooms
      await refresh();
      final repo = _ref.read(pronosticRepositoryProvider);
      final stats = await repo.getUserStats(userId);
      if (stats != null) {
        await RoomRepositoryImpl()
            .updateMemberPoints(userId, stats.totalPoints);
      }
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PROVIDERS DÉRIVÉS — consommés par les widgets
// ─────────────────────────────────────────────────────────────────────────────

/// Stats de l'utilisateur connecté
final userStatsAppProvider = Provider<UserStatsEntity?>((ref) {
  return ref.watch(appStateProvider).userStats;
});

/// Tous les pronostics de l'utilisateur
final userPronosticsAppProvider = Provider<List<PronosticEntity>>((ref) {
  return ref.watch(appStateProvider).pronostics;
});

/// Points live pour un match donné (calcul local, pas Firestore)
final livePointsForMatchProvider = Provider.family<int, String>((ref, matchId) {
  return ref.watch(appStateProvider).livePoints(matchId);
});

/// Pronostic de l'utilisateur pour un match donné
final pronosticForMatchProvider =
    Provider.family<PronosticEntity?, String>((ref, matchId) {
  return ref.watch(appStateProvider).pronosticFor(matchId);
});
