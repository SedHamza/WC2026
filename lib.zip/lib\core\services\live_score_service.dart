import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:wc2026/shared/providers/app_state_provider.dart';
import 'package:wc2026/shared/providers/repository_providers.dart';

final liveScoreServiceProvider =
    StateNotifierProvider<LiveScoreService, LiveScoreState>((ref) {
  return LiveScoreService(ref);
});

class LiveScoreState {
  final bool isRefreshing;
  final int liveMatchCount;

  const LiveScoreState({this.isRefreshing = false, this.liveMatchCount = 0});

  LiveScoreState copyWith({bool? isRefreshing, int? liveMatchCount}) {
    return LiveScoreState(
      isRefreshing: isRefreshing ?? this.isRefreshing,
      liveMatchCount: liveMatchCount ?? this.liveMatchCount,
    );
  }
}

class LiveScoreService extends StateNotifier<LiveScoreState> {
  final Ref _ref;
  Timer? _timer;
  static const _interval = Duration(seconds: 60);

  LiveScoreService(this._ref) : super(const LiveScoreState());

  Future<void> start() async {
    // Initialise appState : charge stats + pronostics + calcule matchs terminés
    await _ref.read(appStateProvider.notifier).initialize();

    if (_timer?.isActive == true) return;
    await _refreshLive();
    _timer = Timer.periodic(_interval, (_) => _refreshLive());
  }

  void stop() {
    _timer?.cancel();
    _timer = null;
  }

  Future<void> forceRefresh() => _refreshLive();

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _refreshLive() async {
    if (state.isRefreshing) return;
    state = state.copyWith(isRefreshing: true);

    try {
      final repo = _ref.read(matchRepositoryProvider);
      final liveMatches = await repo.getLiveMatches();

      _ref.invalidate(matchesProvider);
      _ref.invalidate(todayMatchesProvider);

      state = state.copyWith(
        isRefreshing: false,
        liveMatchCount: liveMatches.where((m) => m.isLive).length,
      );

      // Met à jour les points live dans appStateProvider
      _ref.read(appStateProvider.notifier).updateLivePoints(liveMatches);

      // Si des matchs viennent de se terminer → recalcule
      final hasNewlyFinished =
          liveMatches.any((m) => m.isFinished && m.homeScore != null);
      if (hasNewlyFinished) {
        await _ref.read(appStateProvider.notifier).initialize();
      }
    } catch (_) {
      state = state.copyWith(isRefreshing: false);
    }
  }
}
